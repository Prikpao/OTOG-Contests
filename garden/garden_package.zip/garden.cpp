#include "garden.h"
#include <bits/stdc++.h>
using namespace std;

int findMinimumTime(int N, int M) {
    //write you code here
    return 0;
}
