#include <bits/stdc++.h>
using namespace std;

int goToSpace(int N, int M, int k, vector<pair<int, int>> v){
    //write your code here
    return -1;
}
